# OIJPCR
## Online Indian Journal of Peace and Conflict Resolution
# Home
![Home](../TinyMCE/Showcase/landing.png)
